import React from 'react';

const Projects = () => {
  return (
    <section className="projects">
      <h2>My Projects</h2>
      <p>List of project cards will go here.</p>
    </section>
  );
};

export default Projects;
