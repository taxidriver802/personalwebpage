import React from 'react';

const Home = () => {
  return (
    <section className="home">
      <h1>Welcome to My Webpage</h1>
      <p>This is the home section. Intro and hero content goes here.</p>
    </section>
  );
};

export default Home;
