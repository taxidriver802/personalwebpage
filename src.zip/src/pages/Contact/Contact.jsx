import React from 'react';

const Contact = () => {
  return (
    <section className="contact">
      <h2>Contact Me</h2>
      <p>Contact form or info will go here.</p>
    </section>
  );
};

export default Contact;
